// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app"
import { getFirestore } from "firebase/firestore"
import { getStorage } from "firebase/storage"
import { getAnalytics } from "firebase/analytics"

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBIy3tbhLkBlt25buHZj8h1T1zo8TTcrFs",
  authDomain: "mwd-quotation-b69b4.firebaseapp.com",
  projectId: "mwd-quotation-b69b4",
  storageBucket: "mwd-quotation-b69b4.firebasestorage.app",
  messagingSenderId: "373593217335",
  appId: "1:373593217335:web:668459d99df7fda968e2b2",
  measurementId: "G-W8PVS2KVWH",
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)

// Initialize Firestore and Storage
export const db = getFirestore(app)
export const storage = getStorage(app)

// Initialize Analytics (only in browser environment)
export const initializeAnalytics = () => {
  if (typeof window !== "undefined") {
    return getAnalytics(app)
  }
  return null
}

export default app

